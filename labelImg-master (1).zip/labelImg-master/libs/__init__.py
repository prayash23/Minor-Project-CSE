__version_info__ = ('1', '8', '6')
__version__ = '.'.join(__version_info__)
